PHP MySQL Form Maker
Version 2.0										
												 
*******************************************************************************************************
*************************
Installation instruction

1.Upload the folder �FormMaker� to your server
2.Give read/write permissions to the following folders: -
    a.FormMaker/forms
    b.FormMaker/wizard/styles
3. browse to the index page of the script, (i.e http://yourservername/path-to-phpmysqlreportmaker/FormMaker/index.php
That is it!
*******************************************************************************************************

How to get help : 
*****************
The product is very easy to install and use, it has a nice and easy wizard style interface, moreover we do support the following 3 help methods : 

1) Context help : 
You will find a context help near each part in UI of the product, just click the small question mark icon, the help will be displayed

2)Video Tutorial : 
 We provide a video tutorial about the product at the following link : http://mysqlreports.com/formtour.html 

3) Support Tickets : 
 If you still have any problems please open a support ticket at http://mysqlreports.com/formtour.html


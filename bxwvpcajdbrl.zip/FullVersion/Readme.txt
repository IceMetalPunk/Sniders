Smart Report Maker 
Version 5.0										
												 
*******************************************************************************************************
*************************
Installation instruction

1.Upload the folder �SmartReportMaker� to your server
2.Give read/write permissions to the following folders: -
    a.SmartReportMaker/SRM/reports
    b.SmartReportMaker/SRM/wizard/styles
3. browse to the index page of the script, (i.e http://yourservername/path-to-SmartReportMaker/SRM/index.php
That is it!
*******************************************************************************************************

How to get help : 
*****************
The product is very easy to install and use, it supports an easy wizard style interface, moreover we do support the following 3 help methods : 

1) Context help : 
You will find a context help near each element of the product screans, just click the small question mark icon, the help will be displayed

2)Video Tutorial : 
 We provide a very detailed video tutorial about the product at the following link : http://mysqlreports.com/

3) Support Tickets : 
 If you still have any problems please open a support ticket at http://mysqlreports.com/formtour.html


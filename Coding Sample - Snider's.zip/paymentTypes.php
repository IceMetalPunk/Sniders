<?php
	$types=array(
		"Cash Payment"=>26,
		"Credit Card Payment"=>22,
		"Check Payment"=>23,
		"Write-Off"=>24,
		"Other Payment"=>25,
		"Charge for Lost Item"=>31,
		"Misc. Charge"=>32,
		"Delivery Charge"=>33,
		"Misc. Credit"=>41,
		"Not Used"=>42
	);
?>